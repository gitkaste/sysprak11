/* Semaphore defines */
/* General */
#define SEM_LOGGER 0
/* Server */
#define SEM_FILELIST 1
/* Client */
#define SEM_CONSOLER 1
#define SEM_RESULTS 2
